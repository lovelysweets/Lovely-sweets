/* ===================== DATA ===================== */
const palette6 = ['#c68a4b','#7a5230','#e9cd8b','#f0d6ce','#b3564a','#8a9a5b'];

const collections = ["Best Sellers","Gourmet Chocolate","International Candy","Japanese Favorites","Korean Snacks","Mexican Candy","European Treats","Freeze-Dried Candy","Sour Candy","Luxury Gift Boxes","Seasonal Collections","New Arrivals","TikTok Trending"];

function candyVisual(shape, colors, tone){
  colors = colors || ['#c68a4b','#7a5230','#e9cd8b'];
  if(shape==='lolli'){
    return `<div class="candy lolli"><div class="pop" style="background:radial-gradient(circle at 35% 30%, ${colors[0]}, ${colors[1]} 70%);"></div><div class="stick"></div></div>`;
  }
  if(shape==='bar'){
    return `<div class="candy bar" style="background:linear-gradient(160deg,${colors[0]},${colors[1]});"></div>`;
  }
  if(shape==='gummy'){
    return `<div class="candy gummy" style="background:linear-gradient(160deg,${colors[0]},${colors[1]});"></div>`;
  }
  if(shape==='macaron'){
    return `<div class="candy macaron" style="background:linear-gradient(160deg,${colors[0]},${colors[1]});"></div>`;
  }
  // jar default
  let dots='';
  for(let i=0;i<9;i++){ dots += `<span style="background:${colors[i%colors.length]}"></span>`; }
  return `<div class="candy jarshape"><div class="fill">${dots}</div></div>`;
}

const products = [
  {id:'p1',name:'Belgian 72% Dark Truffle Box',collection:'Gourmet Chocolate',origin:'Belgium',price:32,rating:5,badge:'Best Seller',shape:'jar',colors:['#5c4028','#7a5230','#c68a4b']},
  {id:'p2',name:'Salted Caramel Sea Bonbons',collection:'Gourmet Chocolate',origin:'France',price:26,rating:5,badge:null,shape:'bar',colors:['#c68a4b','#8a5a2a']},
  {id:'p3',name:'Hazelnut Praline Lollies',collection:'Gourmet Chocolate',origin:'Italy',price:18,rating:4,badge:'New',shape:'lolli',colors:['#b3854b','#7a5230']},
  {id:'p4',name:'Japanese Matcha Kit Kat',collection:'Japanese Favorites',origin:'Japan',price:9,rating:5,badge:'TikTok Trending',shape:'bar',colors:['#8a9a5b','#5f6e3d']},
  {id:'p5',name:'Hi-Chew Assorted Fruit',collection:'Japanese Favorites',origin:'Japan',price:6,rating:5,badge:'Best Seller',shape:'gummy',colors:['#e26b6b','#e9cd8b']},
  {id:'p6',name:'Pocky Chocolate Sticks',collection:'Japanese Favorites',origin:'Japan',price:5,rating:4,badge:null,shape:'bar',colors:['#7a5230','#3b2a1f']},
  {id:'p7',name:'Ramune Soda Candy',collection:'Japanese Favorites',origin:'Japan',price:5,rating:4,badge:null,shape:'jar',colors:['#7fb3c9','#e9f3f5','#c9e0e8']},
  {id:'p8',name:'Korean Pepero Almond',collection:'Korean Snacks',origin:'South Korea',price:6,rating:4,badge:'New',shape:'bar',colors:['#b58a4b','#7a5230']},
  {id:'p9',name:'Honey Butter Chips',collection:'Korean Snacks',origin:'South Korea',price:7,rating:5,badge:'TikTok Trending',shape:'jar',colors:['#e9cd8b','#c68a4b','#f0e3c0']},
  {id:'p10',name:'Lucas Muecas Tamarind',collection:'Mexican Candy',origin:'Mexico',price:4,rating:4,badge:null,shape:'gummy',colors:['#c9622b','#7a3d1a']},
  {id:'p11',name:'Pulparindo Tamarind Bar',collection:'Mexican Candy',origin:'Mexico',price:4,rating:4,badge:null,shape:'bar',colors:['#8a4a2a','#5c3018']},
  {id:'p12',name:'Pelon Pelo Rico',collection:'Mexican Candy',origin:'Mexico',price:5,rating:4,badge:'New',shape:'lolli',colors:['#d9714a','#7a3d1a']},
  {id:'p13',name:'British Cadbury Twirl',collection:'European Treats',origin:'United Kingdom',price:6,rating:5,badge:'Best Seller',shape:'bar',colors:['#4a2e1a','#7a5230']},
  {id:'p14',name:'German Haribo Goldbears',collection:'European Treats',origin:'Germany',price:5,rating:5,badge:'Best Seller',shape:'gummy',colors:['#e2b13a','#e26b6b']},
  {id:'p15',name:'Kinder Bueno Duo',collection:'European Treats',origin:'Germany',price:5,rating:5,badge:null,shape:'bar',colors:['#c68a4b','#7a5230']},
  {id:'p16',name:'Milka Alpine Milk Bar',collection:'European Treats',origin:'Germany',price:5,rating:4,badge:null,shape:'bar',colors:['#8a5aa0','#6a3d80']},
  {id:'p17',name:'Turkish Delight, Rosewater',collection:'European Treats',origin:'Turkey',price:14,rating:4,badge:'New',shape:'jar',colors:['#e2a3b0','#f0d6ce','#d97b8f']},
  {id:'p18',name:'Australian Tim Tam Original',collection:'International Candy',origin:'Australia',price:6,rating:5,badge:'TikTok Trending',shape:'bar',colors:['#4a2e1a','#7a5230']},
  {id:'p19',name:'Freeze-Dried Skittles',collection:'Freeze-Dried Candy',origin:'USA',price:11,rating:5,badge:'TikTok Trending',shape:'jar',colors:['#e26b6b','#e2b13a','#8a9a5b','#7fb3c9']},
  {id:'p20',name:'Freeze-Dried Strawberry Bites',collection:'Freeze-Dried Candy',origin:'USA',price:12,rating:4,badge:'New',shape:'gummy',colors:['#e2607a','#b3384f']},
  {id:'p21',name:'Sour Belt Rainbow Ropes',collection:'Sour Candy',origin:'USA',price:8,rating:4,badge:null,shape:'gummy',colors:['#e2b13a','#e26b6b']},
  {id:'p22',name:'Sour Patch Signature Jar',collection:'Sour Candy',origin:'USA',price:10,rating:5,badge:'Best Seller',shape:'jar',colors:['#8a9a5b','#e26b6b','#e2b13a']},
  {id:'p23',name:'Champagne Gummy Bears',collection:'Luxury Gift Boxes',origin:'France',price:22,rating:5,badge:'Limited Edition',shape:'gummy',colors:['#e9cd8b','#c6a15b']},
  {id:'p24',name:'Gold Leaf Chocolate Coins',collection:'Luxury Gift Boxes',origin:'Belgium',price:28,rating:5,badge:'Limited Edition',shape:'jar',colors:['#c6a15b','#e9cd8b','#7a5230']},
  {id:'p25',name:'Autumn Spiced Caramel Apples',collection:'Seasonal Collections',origin:'USA',price:16,rating:4,badge:'New',shape:'gummy',colors:['#b3564a','#7a5230']},
  {id:'p26',name:'Rosé Macaron Tower',collection:'Seasonal Collections',origin:'France',price:34,rating:5,badge:'Limited Edition',shape:'macaron',colors:['#f0d6ce','#e2a3b0']},
  {id:'p27',name:'Blush Peony Macarons',collection:'New Arrivals',origin:'France',price:20,rating:5,badge:'New',shape:'macaron',colors:['#f0d6ce','#e9cd8b']},
  {id:'p28',name:'Midnight Mocha Sea Salt Bar',collection:'New Arrivals',origin:'Switzerland',price:12,rating:4,badge:'New',shape:'bar',colors:['#3b2a1f','#7a5230']},
];

/* Taste the world country data (country -> product ids) */
const worldMap = {
  'Japan':['p4','p5','p6','p7'],
  'South Korea':['p8','p9'],
  'Mexico':['p10','p11','p12'],
  'United Kingdom':['p13'],
  'Germany':['p14','p15','p16'],
  'France':['p2','p23','p26'],
  'Italy':['p3'],
  'Turkey':['p17'],
  'Australia':['p18'],
  'Canada':['p19'],
};

const giftProducts = ['p23','p24','p17','p26'];

const boxCandies = [
  {id:'b1',name:'Champagne Gummy Bear',shape:'gummy',colors:['#e9cd8b','#c6a15b']},
  {id:'b2',name:'Dark Truffle',shape:'jarshape',colors:['#3b2a1f','#7a5230']},
  {id:'b3',name:'Rose Macaron',shape:'macaron',colors:['#f0d6ce','#e2a3b0']},
  {id:'b4',name:'Sour Belt',shape:'gummy',colors:['#e2b13a','#e26b6b']},
  {id:'b5',name:'Caramel Lolli',shape:'lolli',colors:['#c68a4b','#7a5230']},
  {id:'b6',name:'Matcha Bar',shape:'bar',colors:['#8a9a5b','#5f6e3d']},
  {id:'b7',name:'Tamarind Gummy',shape:'gummy',colors:['#c9622b','#7a3d1a']},
  {id:'b8',name:'Gold Coin Choc',shape:'jarshape',colors:['#c6a15b','#e9cd8b']},
  {id:'b9',name:'Blush Macaron',shape:'macaron',colors:['#f0d6ce','#e9cd8b']},
  {id:'b10',name:'Praline Lolli',shape:'lolli',colors:['#b3854b','#7a5230']},
];

const boxSizes = [
  {id:'petite',label:'Petite Box',cap:6,price:16},
  {id:'signature',label:'Signature Box',cap:12,price:24},
  {id:'grand',label:'Grand Box',cap:20,price:38},
];

/* ===================== STATE ===================== */
let cart = []; // {id,name,price,qty,shape,colors}
let favorites = new Set();
let activeCollection = 'All';
let activeCountry = 'Japan';
let boxSize = boxSizes[1];
let boxItems = [];

/* ===================== RENDER: JAR WALL ===================== */
function renderJarWall(){
  const wall = document.getElementById('jarWall');
  const jars = collections.slice(0,8);
  wall.innerHTML = jars.map((c,i)=>{
    const colors = [palette6[i%6], palette6[(i+2)%6], palette6[(i+4)%6]];
    let dots='';
    for(let k=0;k<8;k++){ dots += `<span style="background:${colors[k%colors.length]}"></span>`; }
    return `<button class="jar" onclick="scrollToCollection('${c}')" aria-label="${c}">
      <div class="jar-lid"></div>
      <div class="jar-glass"><div class="jar-fill">${dots}</div></div>
      <div class="jar-label">${c}</div>
    </button>`;
  }).join('');
}
function scrollToCollection(c){
  activeCollection = c;
  document.getElementById('shop').scrollIntoView({behavior:'smooth'});
  renderChips(); renderShopGrid();
}

/* ===================== RENDER: CHIPS + SHOP GRID ===================== */
function renderChips(){
  const row = document.getElementById('chipRow');
  const all = ['All', ...collections];
  row.innerHTML = all.map(c=>`<button class="chip ${c===activeCollection?'active':''}" onclick="setCollection('${c}')">${c}</button>`).join('');
}
function setCollection(c){ activeCollection=c; renderChips(); renderShopGrid(); }

function starString(n){
  let s='';
  for(let i=0;i<5;i++){ s += i<n ? '★' : '<span>★</span>'; }
  return s;
}

function productCard(p){
  return `<div class="card">
    ${p.badge ? `<div class="badge ${p.badge==='Limited Edition'?'limited':p.badge==='New'?'new':''}">${p.badge}</div>` : ''}
    <button class="fav-btn ${favorites.has(p.id)?'active':''}" onclick="toggleFav('${p.id}',this)" aria-label="Favorite">
      <svg viewBox="0 0 24 24"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 1 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/></svg>
    </button>
    <div class="card-visual">${candyVisual(p.shape,p.colors)}</div>
    <div class="origin">${p.origin}</div>
    <h3>${p.name}</h3>
    <div class="stars">${starString(p.rating)}</div>
    <div class="card-foot">
      <span class="price">$${p.price.toFixed(2)}</span>
      <button class="add-btn" onclick="addToCart('${p.id}')" aria-label="Add to cart">+</button>
    </div>
  </div>`;
}

function renderShopGrid(){
  const grid = document.getElementById('shopGrid');
  let list = activeCollection==='All' ? products : products.filter(p=>p.collection===activeCollection);
  if(list.length===0) list = products.slice(0,8);
  grid.innerHTML = list.map(productCard).join('');
}

/* ===================== RENDER: TASTE THE WORLD ===================== */
function renderCountryTabs(){
  const el = document.getElementById('countryTabs');
  el.innerHTML = Object.keys(worldMap).map(c=>`<button class="country-tab ${c===activeCountry?'active':''}" onclick="setCountry('${c}')">${c}</button>`).join('');
}
function setCountry(c){ activeCountry=c; renderCountryTabs(); renderWorldGrid(); }
function renderWorldGrid(){
  const grid = document.getElementById('worldGrid');
  const ids = worldMap[activeCountry] || [];
  const list = products.filter(p=>ids.includes(p.id));
  grid.innerHTML = list.map(productCard).join('');
}

/* ===================== RENDER: GIFTS ===================== */
function renderGifts(){
  const grid = document.getElementById('giftGrid');
  const list = products.filter(p=>giftProducts.includes(p.id));
  grid.innerHTML = list.map(productCard).join('');
}

/* ===================== FAVORITES ===================== */
function toggleFav(id, btn){
  if(favorites.has(id)){ favorites.delete(id); btn.classList.remove('active'); }
  else{ favorites.add(id); btn.classList.add('active'); showToast('Saved to favorites'); }
}

/* ===================== CART ===================== */
function findProduct(id){
  if(id==='spotlight') return {id:'spotlight',name:'Yuzu Gold Truffle Collection',price:38,shape:'jarshape',colors:['#c6a15b','#3b2a1f','#e9cd8b']};
  return products.find(p=>p.id===id);
}
function addToCart(id){
  const p = findProduct(id);
  if(!p) return;
  const existing = cart.find(c=>c.id===id);
  if(existing){ existing.qty++; } else { cart.push({...p, qty:1}); }
  updateCartUI();
  showToast(p.name + ' added to bag');
  openCart();
}
function changeQty(id, delta){
  const item = cart.find(c=>c.id===id);
  if(!item) return;
  item.qty += delta;
  if(item.qty<=0) cart = cart.filter(c=>c.id!==id);
  updateCartUI();
}
function removeItem(id){ cart = cart.filter(c=>c.id!==id); updateCartUI(); }

function cartSubtotal(){ return cart.reduce((s,c)=>s+c.price*c.qty,0); }

function updateCartUI(){
  const count = cart.reduce((s,c)=>s+c.qty,0);
  document.getElementById('cartCount').textContent = count;
  const body = document.getElementById('cartBody');
  if(cart.length===0){
    body.innerHTML = `<div class="empty-cart">Your bag is empty — every jar is waiting to be discovered.<br><br><a href="#shop" class="btn btn-outline" onclick="closeCart()">Start Shopping</a></div>`;
  } else {
    body.innerHTML = cart.map(c=>`
      <div class="cart-item">
        <div class="card-visual" style="width:56px;height:56px;flex:0 0 auto;border-radius:12px;">${candyVisual(c.shape,c.colors)}</div>
        <div class="ci-info">
          <h5>${c.name}</h5>
          <div class="qty-row">
            <button class="qty-btn" onclick="changeQty('${c.id}',-1)">−</button>
            <span>${c.qty}</span>
            <button class="qty-btn" onclick="changeQty('${c.id}',1)">+</button>
            <button class="remove-btn" onclick="removeItem('${c.id}')">Remove</button>
          </div>
        </div>
        <span style="font-weight:800;">$${(c.price*c.qty).toFixed(2)}</span>
      </div>`).join('');
  }
  const subtotal = cartSubtotal();
  const goal = 65;
  const pct = Math.min(100, (subtotal/goal)*100);
  const remaining = Math.max(0, goal-subtotal).toFixed(2);
  const foot = document.getElementById('cartFoot');
  const addonPool = products.slice(0,6);
  foot.innerHTML = `
    <div style="font-size:12px;color:var(--taupe);margin-bottom:8px;">
      ${subtotal>=goal ? "You've unlocked free shipping!" : `$${remaining} away from free shipping`}
    </div>
    <div class="progress-track"><div class="progress-fill" style="width:${pct}%;"></div></div>
    <div class="eyebrow" style="margin:16px 0 8px;">You might also like</div>
    <div class="addon-strip">
      ${addonPool.map(p=>`<div class="addon-chip">${p.name.split(' ').slice(0,2).join(' ')}<button onclick="addToCart('${p.id}')">Add</button></div>`).join('')}
    </div>
    <div class="subtotal-row"><span>Subtotal</span><span>$${subtotal.toFixed(2)}</span></div>
    <div class="pay-row">
      <span class="pay-pill">Apple Pay</span><span class="pay-pill">Google Pay</span><span class="pay-pill">PayPal</span><span class="pay-pill">Shop Pay</span><span class="pay-pill">Credit Card</span>
    </div>
    <button class="checkout-btn" onclick="showToast('Checkout is just for show in this preview')">Checkout</button>
  `;
}

function openCart(){ document.getElementById('cartDrawer').classList.add('open'); document.getElementById('overlay').classList.add('open'); }
function closeCart(){ document.getElementById('cartDrawer').classList.remove('open'); document.getElementById('overlay').classList.remove('open'); }

/* ===================== BOX BUILDER ===================== */
function renderSizeRow(){
  const row = document.getElementById('sizeRow');
  row.innerHTML = boxSizes.map(s=>`<button class="size-opt ${s.id===boxSize.id?'active':''}" onclick="setBoxSize('${s.id}')">
    <b>${s.label}</b><span>Up to ${s.cap} pieces · $${s.price}</span>
  </button>`).join('');
}
function setBoxSize(id){
  boxSize = boxSizes.find(s=>s.id===id);
  if(boxItems.length > boxSize.cap) boxItems = boxItems.slice(0, boxSize.cap);
  renderSizeRow(); renderPalette(); renderBoxPreview();
}
function renderPalette(){
  const el = document.getElementById('palette');
  el.innerHTML = boxCandies.map(c=>{
    const count = boxItems.filter(x=>x===c.id).length;
    const maxed = boxItems.length >= boxSize.cap;
    return `<button class="palette-item ${maxed?'maxed':''}" onclick="addToBox('${c.id}')">
      ${candyVisual(c.shape==='jarshape'?'jar':c.shape, c.colors)}
      <div class="pname">${c.name}${count?` (${count})`:''}</div>
    </button>`;
  }).join('');
}
function addToBox(id){
  if(boxItems.length >= boxSize.cap) { showToast('Box is full — remove a piece first'); return; }
  boxItems.push(id);
  renderPalette(); renderBoxPreview();
}
function renderBoxPreview(){
  const visual = document.getElementById('boxVisual');
  visual.innerHTML = boxItems.map(id=>{
    const c = boxCandies.find(x=>x.id===id);
    return `<div class="dot" style="background:linear-gradient(160deg,${c.colors[0]},${c.colors[1]});" title="${c.name}"></div>`;
  }).join('');
  document.getElementById('boxCountLabel').textContent = `${boxItems.length} / ${boxSize.cap} picked`;
  document.getElementById('boxPriceLabel').textContent = `$${boxSize.price.toFixed(2)}`;
  document.getElementById('boxProgress').style.width = `${(boxItems.length/boxSize.cap)*100}%`;
}
function addBoxToCart(){
  if(boxItems.length===0){ showToast('Pick at least one candy first'); return; }
  const label = `${boxSize.label} (${boxItems.length} pcs)`;
  cart.push({id:'box-'+Date.now(), name:label, price:boxSize.price, qty:1, shape:'jarshape', colors:['#c6a15b','#7a5230']});
  updateCartUI();
  showToast('Your custom box was added to the bag');
  openCart();
}

/* ===================== SPOTLIGHT JAR FILL ===================== */
function renderSpotlightFill(){
  const el = document.getElementById('spotlightFill');
  const colors = ['#c6a15b','#3b2a1f','#e9cd8b'];
  let dots='';
  for(let i=0;i<9;i++){ dots += `<span style="background:${colors[i%3]}"></span>`; }
  el.innerHTML = dots;
}

/* ===================== NEWSLETTER ===================== */
function subscribeNL(form){
  showToast("You're on the list — welcome to Lovely Sweets");
  form.reset();
}

/* ===================== TOAST ===================== */
let toastTimer;
function showToast(msg){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(()=>t.classList.remove('show'), 2400);
}

/* ===================== SCROLL EFFECTS ===================== */
window.addEventListener('scroll', ()=>{
  document.getElementById('siteHeader').classList.toggle('scrolled', window.scrollY>40);
});
const io = new IntersectionObserver((entries)=>{
  entries.forEach(e=>{ if(e.isIntersecting) e.target.classList.add('in'); });
},{threshold:.15});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));

/* ===================== INIT ===================== */
renderJarWall();
renderChips();
renderShopGrid();
renderCountryTabs();
renderWorldGrid();
renderGifts();
renderSizeRow();
renderPalette();
renderBoxPreview();
renderSpotlightFill();
updateCartUI();

# Lovely Sweets

A luxury candy boutique website — quiet-luxury visual design (cream, champagne, mocha, gold) with an interactive candy jar hero, a full shop with 13 collections, a "Taste the World" country explorer, a Build Your Own Candy Box tool, and a working slide-out cart. No image assets — every candy visual is drawn in CSS, so there's nothing to break or re-host.

## Project structure

```
.
├── index.html      # markup
├── styles.css      # all styling (tokens, layout, components, animations)
├── script.js       # product data, cart, box builder, filters, interactions
└── README.md
```

This is a static site — no build step, no dependencies, no backend.

## Run it locally

Just open `index.html` in a browser, or serve it:

```bash
npx serve .
```

## Deploy to GitHub + Vercel

1. Create a new GitHub repo and push these files:
   ```bash
   git init
   git add .
   git commit -m "Lovely Sweets site"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git push -u origin main
   ```

2. Go to [vercel.com](https://vercel.com), click **Add New → Project**, and import that GitHub repo.

3. Vercel will detect it as a static site — no framework preset needed, no build command, no output directory required. Just click **Deploy**.

That's it — Vercel will give you a live URL, and every future `git push` to `main` will auto-deploy.

## Notes

- Fonts (Fraunces + Manrope) load from Google Fonts via CDN link tags in `index.html` — no local font files needed.
- All candy/jar/lollipop visuals are CSS gradients and shapes defined in `styles.css` and generated per-product in `script.js` — swap in real photography later by replacing the `candyVisual()` output with `<img>` tags if desired.
